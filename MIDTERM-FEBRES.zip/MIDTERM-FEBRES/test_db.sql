-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2021 at 04:38 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `acts`
--

CREATE TABLE `acts` (
  `id` int(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `activity` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acts`
--

INSERT INTO `acts` (`id`, `username`, `activity`, `time`) VALUES
(8, 'jeproks', 'LogIn', '2021-04-26 19:48:53'),
(9, 'jeproks', 'LogOut', '2021-04-26 19:49:03'),
(10, 'jeproks', 'LogIn', '2021-04-26 21:09:04'),
(11, 'jeproks', 'LogIn', '2021-04-26 22:34:29'),
(12, 'jeproks', 'LogIn', '2021-04-26 23:01:21'),
(13, 'jeproks', 'LogIn', '2021-04-26 23:16:03'),
(14, 'jeproks', 'LogOut', '2021-04-26 23:16:09'),
(15, 'jeproks', 'LogIn', '2021-04-26 23:18:00'),
(16, 'jeproks', 'LogIn', '2021-04-26 23:28:01'),
(17, 'jeproks', 'LogOut', '2021-04-26 23:28:06'),
(18, 'jeproks', 'LogIn', '2021-04-26 23:32:16'),
(19, 'jeproks', 'LogOut', '2021-04-26 23:32:30'),
(20, 'jeproks', 'LogOut', '2021-04-26 23:39:47'),
(21, 'jeproks', 'LogOut', '2021-04-27 01:15:59'),
(22, 'jeproks', 'LogOut', '2021-04-27 01:21:54'),
(23, 'jeproks', 'LogOut', '2021-04-27 01:27:52'),
(24, 'jeproks', '', '2021-04-27 10:30:54'),
(25, 'jeproks', 'LogIn', '2021-04-27 10:31:43'),
(26, 'jeproks', 'LogOut', '2021-04-27 10:32:15'),
(27, 'jeproks', 'ChangePassword', '2021-04-27 10:33:21'),
(28, 'jeproks', 'LogIn', '2021-04-27 10:33:54'),
(29, 'jeproks', 'LogIn', '2021-04-27 10:36:48'),
(30, 'jeproks', 'LogOut', '2021-04-27 10:36:57');

-- --------------------------------------------------------

--
-- Table structure for table `authent`
--

CREATE TABLE `authent` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `otp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bopols`
--

CREATE TABLE `bopols` (
  `id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `otp` int(10) NOT NULL,
  `curdate` varchar(50) NOT NULL,
  `endate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bopols`
--

INSERT INTO `bopols` (`id`, `username`, `otp`, `curdate`, `endate`) VALUES
(15, 'jeproks', 252633, '2021-04-26 19:48:43', '2021-04-26 19:53:43'),
(16, 'jeproks', 126705, '2021-04-26 21:08:58', '2021-04-26 21:13:58'),
(17, 'jeproks', 878401, '2021-04-26 22:26:48', '2021-04-26 22:31:48'),
(18, 'jeproks', 221642, '2021-04-26 22:34:22', '2021-04-26 22:39:22'),
(19, 'jeproks', 364008, '2021-04-26 23:01:16', '2021-04-26 23:06:16'),
(20, 'jeproks', 723701, '2021-04-26 23:15:55', '2021-04-26 23:20:55'),
(21, 'jeproks', 279767, '2021-04-26 23:17:55', '2021-04-26 23:22:55'),
(22, 'jeproks', 146075, '2021-04-26 23:27:44', '2021-04-26 23:32:44'),
(23, 'jeproks', 319462, '2021-04-26 23:32:05', '2021-04-26 23:37:05'),
(24, 'jeproks', 905926, '2021-04-26 23:32:11', '2021-04-26 23:37:11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`) VALUES
(44, 'jeproks', 'Jefstiryo@@12', 'jefinamo@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acts`
--
ALTER TABLE `acts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `authent`
--
ALTER TABLE `authent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bopols`
--
ALTER TABLE `bopols`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acts`
--
ALTER TABLE `acts`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `authent`
--
ALTER TABLE `authent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `bopols`
--
ALTER TABLE `bopols`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
