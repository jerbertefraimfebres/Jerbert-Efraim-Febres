<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
		<style>
		


		body{
			background: url(dahon.jpeg);
		}


		.h1{
			margin: 0;
			padding: 0 0 20px;
			text-align: center;
			font-size: 22px;
			font-family: "Lucida Console", "Courier New", monospace;
				color: black;

		}

		form{
				margin-top:10%;
				font-family: "Lucida Console", "Courier New", monospace;
				color: white;
				width: 350px;
				height: 370px;
				padding-top:40;
				border: white solid 7px;
				border-radius: 10px;	
			}

		input[type="submit"]{

				font-family: "Lucida Console", "Courier New", monospace;
				width:30%;
				height: 10%;
				border: 2px solid black;
				border-radius:5px;
				transition-duration: 0.7s;
				cursor: pointer;
		}

		input[type="submit"]:hover {
				  background-color: black;
				  color: white;
				  border: 2px solid white;
				}


		a{
			color:white;
		}

</style>
</head>
<body>

	<center>
     <form action="login.php" method="post">
		<h1> Log In </h1>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
     	<label>UserName:</label>
     	<input type="text" name="uname" placeholder="UserName"><br><br>

     	<label>Password:</label>
     	<input type="password" name="password" placeholder="Password"><br><br>
			<a href="signup.php" class="ca">Create an account</a><br/><br>
			<a href="changpass.php" class="ca">Forgot Password</a><br><br><br>
     	<input type="submit" value="Log In">
         </center> 
     </form>
</body>
</html>