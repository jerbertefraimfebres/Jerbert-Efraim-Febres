
<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['username'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<style>
		body{
			background: url(dahon.jpeg);
			
		}
		h1 {
		    font-family: "Lucida Console", "Courier New", monospace;
			text-shadow: 2px 2px 5px skyblue;			
			color: white;
			border: 7px ridge;
			border-radius: 10px;
			padding-top: 20px;
			padding-bottom: 20px;
			width:40%;
			font-style: oblique;
		}

		h1 {

			 
			  background-color: white;
			  animation-name: example;
			  animation-duration: 1s;
			  animation-iteration-count: infinite;
			}

			@keyframes example {
			  from {background-color: white;}
			  to {background-color: black;}
			}

		a{
			color:white;
			font-size: 20px;
			border: 2px solid white;
			border-radius:5px;
			padding-top: 10px;
			padding-right: 10px;
			padding-left: 10px;
			padding-bottom: 10px;
			}

		.container{
			margin-top: 10%
		}



		
		</style>
	<title>HOME</title>
	
</head>
<body>
	
	<div class="container">
		<center>
     <h1>Hello, <?php echo $_SESSION['username']; ?>!!</h1>
 </center>
	
		<center>
			<br>
			<br>
			<br>
			<br>
   		  <a href="logout.php">LOGOUT</a><br><br><br>
		 <a href="display.php" >ACTIVITIES</a>
		</center>
	</div>
</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>                            		                            