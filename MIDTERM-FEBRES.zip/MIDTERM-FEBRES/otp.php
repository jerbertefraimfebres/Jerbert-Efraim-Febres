<html>
	<head>
		<title> OTP </title>
					<style>
		body{
			background: url(dahon.jpeg);
		}
		.container{
				margin-top:10%;
				font-family: "Lucida Console", "Courier New", monospace;
				color: white;
				width: 350px;
				height: 370px;
				padding-top:40;
				border: white solid 7px;
				border-radius: 10px;
		}
		
		.h1{
			margin: 0;
			padding: 0 0 20px;
			text-align: center;
			font-size: 22px;
			font-family: "Lucida Console", "Courier New", monospace;
				color: black;
		}

		
		.container input[type="text"], input[type="password"]{
			width: 75%;
			padding: 15px;
			margin: 5px 0 12px 0;
			display: inline-block;
			border: none;
			background: #f1f1f1;	
		}
		.container input[type="submit"]{
				font-family: "Lucida Console", "Courier New", monospace;
				width:25%;
				height:45px;
				border: 2px solid black;
				border-radius:5px;
				transition-duration: 0.7s;
				cursor: pointer;
		}

		.container input[type="submit"]:hover {
				  background-color: black;
				  color: white;
				  border: 2px solid white;
				}

</style>
			
		</head>
	<body>
		<center>
		<form action="otpx.php" method="post">
			<div class="container">
		<h1> Enter </h1>
			
		<p> Enter OTP Code </p>
          <?php if (isset($_GET['num1'])) { ?>
               <input type="text" 
                      name="num1" 
                      placeholder="Username"
                      value="<?php echo $_GET['num1']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="num1" 
                      placeholder="OTP"><br><br><br>
          <?php }?>
			<input type="submit" value="Send">
		</form>
	</center>
	<?php 
?> </div>
		</body>
	</html>