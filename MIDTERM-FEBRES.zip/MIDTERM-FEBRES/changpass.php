<!DOCTYPE html>
<html>
<head>
	<title>Change Password</title>
	<style>
		body{
			font-family: "Lucida Console", "Courier New", monospace;
			background: url(dahon.jpeg);
			}
		.container {
			width:40%;
			padding: 36px;
			color:white;
			border-radius: 40px;
			height: 456;
			margin-left: 27%;
			border: white solid 7px;
			border-radius: 10px;
			}

		.h1{
			margin: 0;
			padding: 0 0 20px;
			text-align: center;
			font-size: 22px;
		}

		.boxer p {
			margin: 0;
			padding: 0;
			font-weight: bold;
		}
		.boxer input{
			width: 100%;
			margin-bottom: 20px;
		}
		.container input[type="text"], input[type="password"]{
			width: 75%;
			padding: 15px;
			margin: 5px 0 12px 0;
			display: inline-block;
			border: none;
			background: #f1f1f1;	
		}
		.container input[type="submit"]{
				font-family: "Lucida Console", "Courier New", monospace;
				width:35%;
				height:45px;
				border: 2px solid black;
				border-radius:5px;
				transition-duration: 0.7s;
				cursor: pointer;
		}

		.container input[type="submit"]:hover {
				  background-color: black;
				  color: white;
				  border: 2px solid white;
				}

			a{
			margin-left: 5%;
			color:white;
		}

</style>
</head>
<body>
	<div class="container"> 
		<h1>Forgot Password</h1>
     <form action="foxcheck.php" method="post">
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>

          <?php if (isset($_GET['success'])) { ?>
               <p class="success"><?php echo $_GET['success']; ?></p>
          <?php } ?>

<p> Username </p>
          <?php if (isset($_GET['uname'])) { ?>
               <input type="text" 
                      name="username" 
                      placeholder="Username"
                      value="<?php echo $_GET['uname']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="uname" 
                      placeholder="Username"><br>
          <?php }?>


     	<p>Password</p>
     	<input type="password" 
                 name="password" 
                 placeholder="Password"><br>

          <p>Re Password</p>
          <input type="password" 
                 name="re_password" 
                 placeholder="Re_Password"><br><br><br>

                 <input type="submit" value="Update Password">
				<a href="index.php" class="ca">Already have an account?</a>
     	
          
     </form>
</body>
</html>